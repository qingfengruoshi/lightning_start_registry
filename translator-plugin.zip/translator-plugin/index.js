const https = require('https');
const querystring = require('querystring');
module.exports = {
    // 核心搜索函数
    search: (query) => {
        return new Promise((resolve) => {
            // 如果没有输入内容，不返回结果
            if (!query) {
                return resolve([]);
            }
            // 这里使用一个免费的翻译接口作为演示 (MyMemory API)
            const url = `https://api.mymemory.translated.net/get?q=${querystring.escape(query)}&langpair=en|zh`;
            https.get(url, (res) => {
                let data = '';
                res.on('data', (chunk) => data += chunk);
                res.on('end', () => {
                    try {
                        const json = JSON.parse(data);
                        const result = json.responseData.translatedText;

                        // 返回符合标准格式的结果数组
                        resolve([{
                            id: 'trans-result',
                            title: result,
                            subtitle: `翻译: ${query}`,
                            icon: '🇨🇳', // 这里暂时用 Emoji 作为图标，避免图片路径问题
                            action: 'copy', // 还需要在主程序实现对应的 action，目前仅作展示
                            data: { text: result }
                        }]);
                    } catch (e) {
                        resolve([]);
                    }
                });
            }).on('error', (e) => {
                resolve([]);
            });
        });
    }
};