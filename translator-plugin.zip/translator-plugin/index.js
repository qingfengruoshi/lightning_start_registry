const https = require('https');
const { shell, clipboard } = require('electron');

module.exports = {
    search: async (query) => {
        if (!query) return [];

        // Remove the trigger word if passed (though usually the app handles triggers, 
        // passing the rest as query. But for plugins, sometimes raw query comes in?)
        // The core logic usually passes the 'remaining' query if a trigger matched.
        // Let's assume 'query' is what the user typed after the trigger.

        const text = query.trim();
        if (!text) return [];

        try {
            const translation = await fetchTranslation(text);

            return [
                {
                    id: 'trans-result',
                    title: translation,
                    subtitle: `Translation for: ${text}`,
                    icon: 'icon.png', // Relative path support to be implemented in core, or use emoji if fails
                    data: {
                        type: 'copy',
                        text: translation
                    }
                },
                {
                    id: 'trans-open',
                    title: 'Open in Google Translate',
                    subtitle: 'Click to open in browser',
                    icon: 'icon.png',
                    data: {
                        type: 'open',
                        url: `https://translate.google.com/?sl=auto&tl=zh-CN&text=${encodeURIComponent(text)}`
                    }
                }
            ];
        } catch (e) {
            return [{
                id: 'error',
                title: 'Translation Failed',
                subtitle: e.message,
                icon: 'icon.png'
            }];
        }
    },

    execute: async (item) => {
        if (item.data.type === 'copy') {
            clipboard.writeText(item.data.text);
            return; // returning allows window to hide
        }
        if (item.data.type === 'open') {
            shell.openExternal(item.data.url);
        }
    }
};

function fetchTranslation(text) {
    return new Promise((resolve, reject) => {
        const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=zh-CN&dt=t&q=${encodeURIComponent(text)}`;

        https.get(url, (res) => {
            if (res.statusCode !== 200) {
                res.resume();
                reject(new Error(`Status: ${res.statusCode}`));
                return;
            }

            let data = '';
            res.on('data', (chunk) => data += chunk);
            res.on('end', () => {
                try {
                    const json = JSON.parse(data);
                    if (json && json[0] && json[0][0] && json[0][0][0]) {
                        resolve(json[0][0][0]);
                    } else {
                        reject(new Error('Invalid response'));
                    }
                } catch (e) {
                    reject(e);
                }
            });
        }).on('error', (err) => reject(err));
    });
}
